import React from "react";
import htm from "htm";
const html = htm.bind(React.createElement);
import { Button, ConfigProvider, theme, Space } from "antd";
import { Typography, Divider } from "antd";
const { Title, Paragraph, Text } = Typography;

export function App() {
  const [count, setCount] = React.useState(0);

  // This looks just like JSX, but it's a standard JS string!
  return html`
    <${ConfigProvider}
      theme=${{
        algorithm: theme.darkAlgorithm,
        token: {
          colorPrimary: "#ff6600", // Orange primary color
          colorBgBase: "#000000", // Pure black background
          colorTextBase: "#ffffff", // White text
          //borderRadius: 4,
        },
      }}
    >
      <${Typography}>
        <div
          style=${{
            padding: "20px",
            background: "#141414",
            borderRadius: "8px",
          }}
        >
          <h1>Ant Design + HTM</h1>
          <${Paragraph}>
            <${Text} code>Some code<//>
          <//>
          <p>Count: ${count}</p>

          <p>This is the text</p>

          <${Space}>
            <${Button} type="primary" onClick=${() => setCount(count + 1)}>
              Increment
            <//>

            <${Button} onClick=${() => setCount(0)}> Reset <//>
          <//>
        </div>
      <//>
    <//>
  `;
}
