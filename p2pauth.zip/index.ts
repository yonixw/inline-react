import express from "express";
import type { Application } from "express";
import path from "path";
import { CSPNonce } from "./src/utils/csp-nonce";

const app: Application = express();
const PORT = 3000;

// Middleware to parse JSON
app.use(express.json({ limit: "10mb" }));

app.use("/public", CSPNonce, express.static(path.join(__dirname, "./public")));

app.listen(PORT, () => {
  console.log(`Server is running at http://localhost:${PORT}`);
});
