import type { Request, Response, NextFunction } from "express";
import crypto from "crypto";
import path from "path";
import fs from "fs";
import { readFile } from "fs/promises";

const PUBLIC_DIR = path.resolve("./public");

export async function CSPNonce(
  req: Request,
  res: Response,
  next: NextFunction
) {
  try {
    const isHtml = req.path.endsWith(".html") || !path.extname(req.path);

    if (isHtml) {
      const nonce = crypto.randomBytes(16).toString("base64url");
      res.locals.nonce = nonce;
      res.setHeader(
        "Content-Security-Policy",
        `default-src 'self'; script-src https://unpkg.com 'self' 'nonce-${nonce}';` +
          `style-src 'self' 'unsafe-inline' ;` +
          `connect-src 'self' https://esm.sh;`
      );

      const safePath = path.normalize(path.join(PUBLIC_DIR, req.path));
      if (!safePath.startsWith(PUBLIC_DIR)) {
        return res.status(403).send("Forbidden: Access Denied");
      }
      let filePath = safePath;

      if (fs.existsSync(filePath) && fs.lstatSync(filePath).isFile()) {
        let data = await readFile(filePath, { encoding: "utf8" });

        const renderedHtml = data.replace(/{{nonce}}/g, res.locals.nonce);
        res.setHeader("Content-Type", "text/html");
        return res.send(renderedHtml);
      }
    }
  } catch (error) {
    return res.status(500).send(`Error reading file: ${error}`);
  }

  next();
}
